# polar-video bundle-2026-05-24 (freebsd-arm64)

Cross-platform install bundle. Run `./install.sh` as root (or via sudo).
The installer detects the OS and copies the right service file + binary
into place. You still need:

  - Postgres reachable (default DSN points at localhost; override via env).
  - polar-dock running and the plugin_modules row minted (see umbrella
    deployment doc).
  - nginx route in front (snippet provided under etc/nginx/).

Full guide: https://github.com/networkextension/Polar/blob/main/doc/deploy.md
